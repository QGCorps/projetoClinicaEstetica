CREATE DATABASE  IF NOT EXISTS `clinica_estetica` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `clinica_estetica`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: clinica_estetica
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `telefone` bigint NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `bairro` varchar(35) NOT NULL,
  `complemento` varchar(60) DEFAULT NULL,
  `cidade` varchar(50) NOT NULL,
  `cpf` bigint DEFAULT NULL,
  `data_nascimento` date NOT NULL,
  `observacao` varchar(1000) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(100) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Ana Carolina Teixeira Reis',11958249651,'Rua Gonçalves Dias, 2305','Jardim Primavera','','Araraquara',441834948,'1994-06-28','','',''),(2,'Bruna Cardosa Brasil de Souza',16988016608,'Avenida Luiz Raia, 472','Vila Suconasa','','Araraquara',36859371897,'1988-03-10','','',''),(3,'Charlene Ribeiro Cunha',16997893111,'Avenida Irmã Antonia de Arruda Camargo, 60','Jardim Vale das Rosas','','Araraquara',29619049861,'1981-10-12','','',''),(4,'Cleusa Montoro Stein',16997827881,'Avenida Pernambuco, 336','Jardim Brasil','','Araraquara',27835371847,'1963-04-15','','',''),(5,'Cristiane Caetano',16997127056,'Avenida Doutor Miguel Couto, 122','Jardim Imperador','','Araraquara',24593411807,'1977-02-28','','',''),(6,'Danielli Brasil Alves Pires',16988647620,'Avenida Dom Carlos Carmello, 371','Vila Suconasa','Apartamento 7, Bloco 03','Araraquara',36859371897,'1988-03-10','','',''),(7,'Francieli Liboni Da Silva',16996427447,'Rua Zenaide Volpe Abjaudi, 143','São José','','Américo Brasiliense',41293001805,'1992-06-15','','',''),(8,'Giovana Carolina Da Silva',16997514154,'Rua Bento Aranha Do Amaral, 13','Vale do Sol','','Araraquara',46356742828,'1997-11-26','','',''),(9,'Gislaine Cristina De Oliveira',16993930873,'Rua Luiz Alecio Sobrinho, 326','Jardim Maria Luiza II','Condomínio Alto da Boa Vista','Araraquara',36663926870,'1989-05-18','','',''),(10,'Jayne Pereira De Macedo',16997117375,'Avenida Votuporanga, 435','Jardim América','','Araraquara',39387830870,'1997-03-19','','',''),(11,'Larissa Montoro Stein Barros',16997757611,'Avenida Nossa Senhora Das Graças, 563','Jardim Melhado','','Araraquara',40897423828,'1991-01-15','','',''),(12,'Maísa Rosa Oliveira Seabra de Andrade',3799844115,'Rua Américo Brasiliense, 534','Vila Ferroviária','','Araraquara',0,'1973-08-29','','',''),(13,'Mércia Sandrini Diogo',16996099343,'Rua Nívea Cunha Fenerich, 201','Jardim Dom Pedro I','','Araraquara',39423763855,'1990-07-01','','',''),(14,'Pâmela Tainá Cassiano',16997949260,'Avenida Dom Carlos Carmelo, 721','Jardim Botânico','Apartamento 402, Bloco 07','Araraquara',44312966893,'1996-04-18','','',''),(15,'Rafaela Del Rio',16997697200,'Rua João de Caires, 34','Vila Furlan','','Araraquara',38502246860,'2000-03-29','','',''),(16,'Vitória Regolin Cayres',16997228572,'Rua das Magnólias, 250','Jardim das Magnólias','','Araraquara',53893037845,'2007-06-19','','',''),(17,'Yasmin Rodrigues da Silva',16997826931,'Rua Gilda Renê Simplício, 137','Parque Residencial Vale do Sol','','Araraquara',54115819820,'2007-12-12','','','');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-23 20:15:42
